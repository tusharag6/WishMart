package com.example.loginsystem;
import java.io.*;
import java.sql.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "LoginServlet", value = "/login-servlet")
public class LoginServlet extends HttpServlet {
    Connection con=null;
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String user_email=request.getParameter("email");
        String user_pwd=request.getParameter("password");
        HttpSession session=request.getSession();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/loginsys?useSSL=false", "root", "primus1w3");
            System.out.println(con + "connection established");
            PreparedStatement st=con.prepareStatement("select * from user where email=? and password=?");
            st.setString(1,user_email);
            st.setString(2,user_pwd);
            ResultSet rs=st.executeQuery();
            RequestDispatcher dispatcher=null;
            if(rs.next()){
                System.out.println("logged in");
                request.setAttribute("status","success");
                session.setAttribute("name",rs.getString("name"));
                dispatcher=request.getRequestDispatcher("Landingpage.jsp");
            }
            else{
                request.setAttribute("status","failed");
                dispatcher=request.getRequestDispatcher("Landingpage.jsp");
            }
            dispatcher.forward(request,response);
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                con.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
    public void destroy() {
    }
}