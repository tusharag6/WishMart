package Signup;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.sql.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
@WebServlet("/signup-servlet")
public class SignUpServlet extends HttpServlet{
    Connection con=null;
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String user_name=request.getParameter("name");
        String user_email=request.getParameter("email");
        String user_pwd=request.getParameter("password");
        PrintWriter out=response.getWriter();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con= DriverManager.getConnection("jdbc:mysql://localhost:3306/loginsys?useSSL=false","root","primus1w3");
            System.out.println(con+"connection established");
            PreparedStatement st= con.prepareStatement("insert into user (name, email, password) values(?,?,?)");
            st.setString(1,user_name);
            st.setString(2,user_email);
            st.setString(3,user_pwd);
            RequestDispatcher dispatcher = null;
            int row=st.executeUpdate();
            if(row>0){
                request.setAttribute("status","success");
                dispatcher =request.getRequestDispatcher("Landingpage.jsp");
            }
            else{
                request.setAttribute("status","failed");
                dispatcher =request.getRequestDispatcher("Landingpage.jsp");
            }
            dispatcher.forward(request,response);
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                con.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void destroy() {
    }
}
